
				</div> <!-- end masonry -->	
		<?php wp_footer(); ?>
	

	</div> <!-- end container -->
	
	
	
		<!--
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/vendor/jquery.min.js"></script>	
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/vendor/underscore-min.js"></script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/vendor/backbone-min.js"></script>
	<script src="http://imagesloaded.desandro.com/imagesloaded.pkgd.min.js"></script>	
	<script src="http://cdnjs.cloudflare.com/ajax/libs/masonry/3.3.2/masonry.pkgd.min.js"></script>	
	
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/models/post.js"></script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/collections/archive.js"></script>
	
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/views/list.js"></script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/views/post.js"></script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/views/core.js"></script>			
	
	
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/routers/router.js"></script>	
	

	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/app.js"></script>
	-->
	</body>
</html>
